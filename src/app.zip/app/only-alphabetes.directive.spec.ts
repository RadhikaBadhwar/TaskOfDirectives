import { OnlyAlphabetesDirective } from './only-alphabetes.directive';

describe('OnlyAlphabetesDirective', () => {
  it('should create an instance', () => {
    const directive = new OnlyAlphabetesDirective();
    expect(directive).toBeTruthy();
  });
});
