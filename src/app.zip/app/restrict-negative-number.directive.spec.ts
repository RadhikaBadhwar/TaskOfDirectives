import { RestrictNegativeNumberDirective } from './restrict-negative-number.directive';

describe('RestrictNegativeNumberDirective', () => {
  it('should create an instance', () => {
    const directive = new RestrictNegativeNumberDirective();
    expect(directive).toBeTruthy();
  });
});
