import { OnlyNumbersDirective } from './only-numbers.directive';

describe('OnlyNumbersDirective', () => {
  it('should create an instance', () => {
    const directive = new OnlyNumbersDirective();
    expect(directive).toBeTruthy();
  });
});
