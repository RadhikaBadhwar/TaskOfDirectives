import { RestrictInputLengthWithSpecificNumberDirective } from './restrict-input-length-with-specific-number.directive';

describe('RestrictInputLengthWithSpecificNumberDirective', () => {
  it('should create an instance', () => {
    const directive = new RestrictInputLengthWithSpecificNumberDirective();
    expect(directive).toBeTruthy();
  });
});
