import { RestrictTwoNumbersAfterDecimalDirective } from './restrict-two-numbers-after-decimal.directive';

describe('RestrictTwoNumbersAfterDecimalDirective', () => {
  it('should create an instance', () => {
    const directive = new RestrictTwoNumbersAfterDecimalDirective();
    expect(directive).toBeTruthy();
  });
});
