import { FirstCharacterSpaceRestrictDirective } from './first-character-space-restrict.directive';

describe('FirstCharacterSpaceRestrictDirective', () => {
  it('should create an instance', () => {
    const directive = new FirstCharacterSpaceRestrictDirective();
    expect(directive).toBeTruthy();
  });
});
