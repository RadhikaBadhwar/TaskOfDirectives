import { Directive, HostListener } from '@angular/core';

@Directive({
  selector: '[appRestrictInputLengthWithSpecificNumber]'
})
export class RestrictInputLengthWithSpecificNumberDirective {

}
