import { RestrictFirstCharacterZeroDirective } from './restrict-first-character-zero.directive';

describe('RestrictFirstCharacterZeroDirective', () => {
  it('should create an instance', () => {
    const directive = new RestrictFirstCharacterZeroDirective();
    expect(directive).toBeTruthy();
  });
});
