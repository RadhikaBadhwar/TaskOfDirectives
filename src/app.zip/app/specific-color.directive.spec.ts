import { SpecificColorDirective } from './specific-color.directive';

describe('SpecificColorDirective', () => {
  it('should create an instance', () => {
    const directive = new SpecificColorDirective();
    expect(directive).toBeTruthy();
  });
});
